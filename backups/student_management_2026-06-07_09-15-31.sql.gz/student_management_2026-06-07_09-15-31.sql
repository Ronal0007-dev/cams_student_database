-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: student_management
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
  `ClassID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` varchar(100) NOT NULL,
  `DeptID` int(11) NOT NULL,
  `Level` int(11) DEFAULT 1 COMMENT 'Used for promotion ordering',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`ClassID`),
  KEY `DeptID` (`DeptID`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`DeptID`) REFERENCES `departments` (`DeptID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` (`ClassID`, `ClassName`, `DeptID`, `Level`, `createdAt`, `updatedAt`) VALUES (1,'Nursery',1,1,'2026-06-05 12:59:30','2026-06-05 12:59:30'),(2,'Reception',1,2,'2026-06-05 12:59:44','2026-06-05 12:59:44'),(3,'Stage One',2,3,'2026-06-05 13:00:05','2026-06-05 13:00:05'),(4,'Stage Two',2,4,'2026-06-05 13:00:22','2026-06-05 13:00:22'),(5,'Stage Three',2,5,'2026-06-05 13:00:48','2026-06-05 13:00:48'),(6,'Stage Four',2,6,'2026-06-05 13:10:32','2026-06-05 13:10:32'),(7,'Stage Five',2,7,'2026-06-05 13:10:59','2026-06-05 13:10:59'),(8,'Stage Six',2,8,'2026-06-05 13:11:22','2026-06-05 13:11:22'),(9,'Year 7',3,9,'2026-06-05 13:11:54','2026-06-05 13:11:54'),(10,'Year 8',3,10,'2026-06-05 13:12:14','2026-06-05 13:12:14'),(11,'Year 9',3,11,'2026-06-05 13:12:28','2026-06-05 13:12:28'),(12,'Year 10',3,12,'2026-06-05 13:12:46','2026-06-05 13:12:46'),(13,'Year 11',3,13,'2026-06-05 13:12:58','2026-06-05 13:12:58'),(14,'Year 12',3,14,'2026-06-05 13:13:11','2026-06-05 13:13:11'),(15,'Year 13',3,15,'2026-06-05 13:13:24','2026-06-05 13:13:24');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `DeptID` int(11) NOT NULL AUTO_INCREMENT,
  `DeptName` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`DeptID`),
  UNIQUE KEY `DeptName` (`DeptName`),
  UNIQUE KEY `DeptName_2` (`DeptName`),
  UNIQUE KEY `DeptName_3` (`DeptName`),
  UNIQUE KEY `DeptName_4` (`DeptName`),
  UNIQUE KEY `DeptName_5` (`DeptName`),
  UNIQUE KEY `DeptName_6` (`DeptName`),
  UNIQUE KEY `DeptName_7` (`DeptName`),
  UNIQUE KEY `DeptName_8` (`DeptName`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`DeptID`, `DeptName`, `Description`, `createdAt`, `updatedAt`) VALUES (1,'EYC','Early Years Centre','2026-06-05 12:50:01','2026-06-05 12:50:01'),(2,'Primary','Primary Section','2026-06-05 12:50:14','2026-06-05 12:50:14'),(3,'Secondary','Secondary Section','2026-06-05 12:50:28','2026-06-05 12:50:28');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `StmID` int(11) NOT NULL AUTO_INCREMENT,
  `StmName` varchar(100) NOT NULL,
  `ClassID` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`StmID`),
  KEY `ClassID` (`ClassID`),
  CONSTRAINT `streams_ibfk_1` FOREIGN KEY (`ClassID`) REFERENCES `classes` (`ClassID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` (`StmID`, `StmName`, `ClassID`, `createdAt`, `updatedAt`) VALUES (1,'Hessonite',3,'2026-06-05 13:13:50','2026-06-05 13:13:50'),(2,'Tanzanite',3,'2026-06-05 13:14:02','2026-06-05 13:14:02'),(3,'Hessonite',4,'2026-06-05 13:14:52','2026-06-05 13:14:52'),(4,'Tanzanite',4,'2026-06-05 13:15:08','2026-06-05 13:15:08'),(5,'Hessonite',5,'2026-06-05 13:15:14','2026-06-05 13:15:14'),(6,'Tanzanite',5,'2026-06-05 13:15:19','2026-06-05 13:15:19'),(7,'Hessonite',6,'2026-06-05 13:15:42','2026-06-05 13:15:42'),(8,'Tanzanite',6,'2026-06-05 13:15:48','2026-06-05 13:15:48'),(9,'Hessonite',7,'2026-06-05 13:15:57','2026-06-05 13:15:57'),(10,'Tanzanite',7,'2026-06-05 13:16:05','2026-06-05 13:16:05'),(11,'Hessonite',8,'2026-06-05 13:16:16','2026-06-05 13:16:16'),(12,'Tanzanite',8,'2026-06-05 13:16:26','2026-06-05 13:16:26'),(13,'Bethlehem',1,'2026-06-05 13:16:46','2026-06-05 13:16:46'),(14,'Bethsaida',1,'2026-06-05 13:16:57','2026-06-05 13:16:57'),(15,'Canaan',1,'2026-06-05 13:17:09','2026-06-05 13:17:09'),(16,'Cana',1,'2026-06-05 13:17:18','2026-06-05 13:17:18'),(17,'Bethan',2,'2026-06-05 13:17:33','2026-06-05 13:17:33'),(18,'Jerusarem',2,'2026-06-05 13:17:44','2026-06-05 13:17:44');
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `StudentID` int(11) NOT NULL AUTO_INCREMENT,
  `StudentFullName` varchar(200) NOT NULL,
  `ParentPhone` varchar(20) DEFAULT NULL,
  `ParentEmail` varchar(150) DEFAULT NULL,
  `ClassID` int(11) NOT NULL,
  `StmID` int(11) DEFAULT NULL,
  `Gender` enum('Male','Female') NOT NULL,
  `Status` enum('Ongoing','Completed','Transferred') NOT NULL DEFAULT 'Ongoing',
  `AdmissionNumber` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `AdmissionDate` date DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`StudentID`),
  UNIQUE KEY `AdmissionNumber` (`AdmissionNumber`),
  UNIQUE KEY `AdmissionNumber_2` (`AdmissionNumber`),
  UNIQUE KEY `AdmissionNumber_3` (`AdmissionNumber`),
  UNIQUE KEY `AdmissionNumber_4` (`AdmissionNumber`),
  KEY `students__class_i_d` (`ClassID`),
  KEY `students__stm_i_d` (`StmID`),
  KEY `students__status` (`Status`),
  KEY `students__gender` (`Gender`),
  CONSTRAINT `students_ibfk_11` FOREIGN KEY (`ClassID`) REFERENCES `classes` (`ClassID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `students_ibfk_12` FOREIGN KEY (`StmID`) REFERENCES `streams` (`StmID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`StudentID`, `StudentFullName`, `ParentPhone`, `ParentEmail`, `ClassID`, `StmID`, `Gender`, `Status`, `AdmissionNumber`, `DateOfBirth`, `AdmissionDate`, `Address`, `createdAt`, `updatedAt`) VALUES (1,'Kalla Ibrahim','+255679929271','kallagiga@gmail.com',4,3,'Male','Ongoing','CAMS/2026/0001','2017-10-24','2026-06-05','P.O Box 597 Dodoma, Tanzania','2026-06-06 12:02:48','2026-06-06 12:02:48'),(2,'Joyce Bira','+255772106878','kallagiga@gmail.com',6,8,'Female','Ongoing','CAMS/2026/0002','2012-05-24','2026-06-06','P.O Box 597 Dodoma, Tanzania','2026-06-06 12:03:41','2026-06-06 12:03:41'),(3,'Boniphace Mateleke','+255679929271','kallagiga@gmail.com',13,NULL,'Male','Completed','CAMS/2026/0003','2017-10-17','2026-06-04','P.O Box 228 Dar es Salaam, Tanzania','2026-06-06 12:04:47','2026-06-06 12:17:57');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(150) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('admin','teacher','viewer') NOT NULL DEFAULT 'viewer',
  `IsActive` tinyint(1) DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `Username_2` (`Username`),
  UNIQUE KEY `Email_2` (`Email`),
  UNIQUE KEY `Username_3` (`Username`),
  UNIQUE KEY `Email_3` (`Email`),
  UNIQUE KEY `Username_4` (`Username`),
  UNIQUE KEY `Email_4` (`Email`),
  UNIQUE KEY `Username_5` (`Username`),
  UNIQUE KEY `Email_5` (`Email`),
  UNIQUE KEY `Username_6` (`Username`),
  UNIQUE KEY `Email_6` (`Email`),
  UNIQUE KEY `Username_7` (`Username`),
  UNIQUE KEY `Email_7` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`UserID`, `FullName`, `Username`, `Email`, `Password`, `Role`, `IsActive`, `createdAt`, `updatedAt`) VALUES (1,'System Administrator','admin','admin@school.ac.tz','$2a$12$VsGtpsqnYJeTNqobhOH1BO0FRdCI.pDkglhvnOf3XwI/ZbN5p.Wsq','admin',1,'2026-06-05 12:46:25','2026-06-05 13:19:50'),(2,'Joyce Bira','Jo-Bira','jobiteko-06@gmail.com','$2a$12$bY74w7tGSW28hFhh89ztDOK1mfWnFFHmaFkWH5yPeg09X9/ZGMIFS','teacher',0,'2026-06-05 13:32:28','2026-06-06 07:41:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'student_management'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-07  9:15:33
